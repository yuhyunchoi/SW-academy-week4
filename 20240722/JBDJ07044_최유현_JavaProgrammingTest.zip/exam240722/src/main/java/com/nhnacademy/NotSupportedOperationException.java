package com.nhnacademy;

public class NotSupportedOperationException extends RuntimeException {

}

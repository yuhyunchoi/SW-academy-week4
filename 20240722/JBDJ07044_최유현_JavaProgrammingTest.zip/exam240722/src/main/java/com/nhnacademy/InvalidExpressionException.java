package com.nhnacademy;

public class InvalidExpressionException extends RuntimeException {

}

package com.nhnacademy;

public class Exam04 {
    static class Node {
    }

    static Node generateAST(String expression) {
        return new Node();
    }

    static int evaluation(String expression) {
        return 0;
    }
}

package com.nhnacademy;

public class NotSupportedBaseException extends RuntimeException {

}
